#ifndef _BOOLEAN_H_
#define _BOOLEAN_H_

/* My favorite names for boolean values */
#define  No 0
#define  Yes	1
#define  Maybe	2				/* tri-state boolean, actually */

#endif							/* _BOOLEAN_H_ */
