NetBSD NOTES
============

This module has been tested on NetBSD 1.6, NetBSD 2.0 and NetBSD 3.0.
It should also work on NetBSD 1.5, and probably any newer releases of
NetBSD with little or no changes.
